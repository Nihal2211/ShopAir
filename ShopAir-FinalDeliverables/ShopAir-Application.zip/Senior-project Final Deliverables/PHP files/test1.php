
<?php


$link = mysql_connect('localhost','root','root');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
echo 'Connected successfully';
mysql_close($link);
mysql_select_db("ShopAir1")
    or die("<p>Error selecting the database ShopAir1: " .
    mysql_error() . "</p>");
  echo "<p>Connected to MySQL, using database ShopAir1.</p>";
      $result = mysql_query("SHOW TABLES;");
  if (!$result) {
    die("<p>Error in listing tables: " . mysql_error() . "</p>");
  }
  echo "<p>Tables in database:</p>";
  echo "<ul>";
  while ($row = mysql_fetch_row($result)) {
    echo "<li>Table: {$row[0]}</li>";
  }
  echo "</ul>";


$name=$_GET['name'];
$last=$_GET['last'];
$email=$_GET['email'];
echo "hello " . $email;
$os = array("Mac", "NT", "Irix", "Linux");


if (in_array($email, $os)) {
   $name="ghaya";
    $last="ghaya";
    $email="ghaya";
    $select_query = "Insert into User (F_name,L_Name,Email) values('$name','$last','$email');";

}else { 
  $select_query = "Insert into User (F_name,L_Name,Email) values('$name','$last','$email');";

  array_push($os, $email);
}
$result = mysql_query($select_query);

$error = mysql_error();
echo $error;
$row = mysql_fetch_array($result);
if(!$row){$result = "Customer is not found"; }
else{
$result = "Customer is found";}

?>


