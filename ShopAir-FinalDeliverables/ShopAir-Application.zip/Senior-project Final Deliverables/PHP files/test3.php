
<?php


mysql_connect("localhost", "root", "root")
or die("<p>Error connecting to database: " . mysql_error() . "</p>");
mysql_select_db("ShopAir1")
or die("<p>Error selecting the database ShopAir1 " .
mysql_error() . "</p>");



$gender=$_GET['gender'];
$shopid=$_GET['shopid'];
$email=$_GET['email'];



 $rs = mysql_query("CALL new_procedure12 ('" . $email . "', '" . $gender . "', " . $shopid .", @product_name, @discount)" );

if(!$rs)
  die("CALL failed " . $mysql->errno . ") " . $mysql->error);

$category_result = mysql_query("SELECT @product_name");
 while($row = mysql_fetch_row($category_result))
 {
 	 echo $row[0];
} 
echo ",";
$category_result1 = mysql_query("SELECT @discount");
 while($row = mysql_fetch_row($category_result1))
 {
 	 echo $row[0];
} 


?>
