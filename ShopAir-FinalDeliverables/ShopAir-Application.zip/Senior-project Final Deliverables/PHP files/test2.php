
<?php


mysql_connect("localhost", "root", "root")
or die("<p>Error connecting to database: " . mysql_error() . "</p>");
echo "<p>Connected to MySQL!</p>";
mysql_select_db("ShopAir1")
or die("<p>Error selecting the database ShopAir1 " .
mysql_error() . "</p>");
echo "<p>Connected to MySQL, using ShopAir1.</p>";


$preference=$_GET['preference'];
$num=$_GET['num'];
$email=$_GET['email'];
echo "hello 1 : " .$preference;
echo "hello 2 : " .$num;
echo "hello 3 : " .$email;

 $rs = mysql_query("CALL new_procedure10 ('" . $email . "', " . $preference . ", " . $num .")" );

if(!$rs)
  die("CALL failed " . $mysql->errno . ") " . $mysql->error);

 echo 'procedure called';


?>


