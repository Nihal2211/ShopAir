-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2014 at 04:58 PM
-- Server version: 5.5.38
-- PHP Version: 5.6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ShopAir1`
--
CREATE DATABASE IF NOT EXISTS `ShopAir1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ShopAir1`;

-- --------------------------------------------------------

--
-- Table structure for table `Beacon`
--

DROP TABLE IF EXISTS `Beacon`;
CREATE TABLE `Beacon` (
  `ID` int(11) NOT NULL,
  `Minor_Number` int(11) NOT NULL,
  `Distance` float DEFAULT NULL,
  `Shop_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Cart`
--

DROP TABLE IF EXISTS `Cart`;
CREATE TABLE `Cart` (
  `ID` int(11) NOT NULL,
  `Amount` float DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Shop_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Preferences`
--

DROP TABLE IF EXISTS `Preferences`;
CREATE TABLE `Preferences` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Preferences`
--

INSERT INTO `Preferences` (`ID`, `Name`) VALUES
(1, 'Fashion'),
(2, 'Electronics'),
(3, 'Music'),
(4, 'Souvenier');

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
CREATE TABLE `Product` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Preferences_ID` int(11) DEFAULT NULL,
  `IF_new` tinyint(1) DEFAULT NULL,
  `IF_Discount` tinyint(1) DEFAULT NULL,
  `Discount_Percentage` int(11) DEFAULT NULL,
  `Shop_ID` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`ID`, `Name`, `Description`, `Preferences_ID`, `IF_new`, `IF_Discount`, `Discount_Percentage`, `Shop_ID`, `Price`, `Quantity`, `Gender`) VALUES
(1, 'Heels', ' Our latest summer 2014 collection includes\nNeon colored heels', 1, 0, 1, 30, 45148, 600, 3, 'female'),
(2, 'Jacket', ' Our latest Winter 2014 collection includes\nJacket', 1, 0, 1, 25, 45148, 2000, 4, 'male'),
(3, 'Wearables Tech', ' Our Lates tech collection includes\nWearable wear', 2, 0, 1, 15, 48173, 1500, 14, 'male');

-- --------------------------------------------------------

--
-- Table structure for table `Product_Category`
--

DROP TABLE IF EXISTS `Product_Category`;
CREATE TABLE `Product_Category` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Shop`
--

DROP TABLE IF EXISTS `Shop`;
CREATE TABLE `Shop` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Shop_Type_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Shop`
--

INSERT INTO `Shop` (`ID`, `Name`, `Shop_Type_ID`) VALUES
(1001, 'Mango', 1),
(1002, 'Emax', 2),
(1003, 'MusicShop', 3),
(1004, 'Giftie', 4),
(45148, 'Harrods', 1),
(48173, 'Samsung', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Shop_Type`
--

DROP TABLE IF EXISTS `Shop_Type`;
CREATE TABLE `Shop_Type` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Shop_Type`
--

INSERT INTO `Shop_Type` (`ID`, `Name`) VALUES
(1, 'Fashion'),
(2, 'Electronics'),
(3, 'Music'),
(4, 'Souvenier'),
(5, 'Home Decor'),
(6, 'Home Appliances'),
(7, 'Greeting Card');

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
`id` int(30) NOT NULL,
  `F_Name` varchar(45) NOT NULL,
  `L_Name` varchar(45) DEFAULT NULL,
  `Email` varchar(45) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`id`, `F_Name`, `L_Name`, `Email`) VALUES
(44, 'Nihal', 'Fathima', 'snajeebkhadri@gmail.com'),
(51, 'Khaled', 'Fares', 'fireball0.1@hotmail.com'),
(58, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `User_Preferences`
--

DROP TABLE IF EXISTS `User_Preferences`;
CREATE TABLE `User_Preferences` (
`UP_ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Preferences_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_Preferences`
--

INSERT INTO `User_Preferences` (`UP_ID`, `User_ID`, `Preferences_ID`) VALUES
(11, 51, 1),
(12, 44, 1),
(13, 51, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Beacon`
--
ALTER TABLE `Beacon`
 ADD PRIMARY KEY (`ID`), ADD KEY `fk_Beacon_Shop1_idx` (`Shop_ID`);

--
-- Indexes for table `Cart`
--
ALTER TABLE `Cart`
 ADD PRIMARY KEY (`ID`), ADD KEY `fk_Cart_Shop1_idx` (`Shop_ID`), ADD KEY `fk_Cart_User1_idx` (`User_ID`);

--
-- Indexes for table `Preferences`
--
ALTER TABLE `Preferences`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
 ADD PRIMARY KEY (`ID`), ADD KEY `Preferences_ID` (`Preferences_ID`), ADD KEY `Shop_ID` (`Shop_ID`);

--
-- Indexes for table `Product_Category`
--
ALTER TABLE `Product_Category`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Shop`
--
ALTER TABLE `Shop`
 ADD PRIMARY KEY (`ID`), ADD KEY `fk_Shop_Shop_Type1_idx` (`Shop_Type_ID`);

--
-- Indexes for table `Shop_Type`
--
ALTER TABLE `Shop_Type`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `User_Preferences`
--
ALTER TABLE `User_Preferences`
 ADD PRIMARY KEY (`UP_ID`), ADD KEY `User_ID` (`User_ID`), ADD KEY `Preferences_ID` (`Preferences_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `User_Preferences`
--
ALTER TABLE `User_Preferences`
MODIFY `UP_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Beacon`
--
ALTER TABLE `Beacon`
ADD CONSTRAINT `fk_Beacon_Shop1` FOREIGN KEY (`Shop_ID`) REFERENCES `Shop` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Cart`
--
ALTER TABLE `Cart`
ADD CONSTRAINT `fk_Cart_Shop1` FOREIGN KEY (`Shop_ID`) REFERENCES `Shop` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Cart_User1` FOREIGN KEY (`User_ID`) REFERENCES `User` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Product`
--
ALTER TABLE `Product`
ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`Preferences_ID`) REFERENCES `Preferences` (`ID`),
ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`Shop_ID`) REFERENCES `SHOP` (`ID`);

--
-- Constraints for table `Shop`
--
ALTER TABLE `Shop`
ADD CONSTRAINT `fk_Shop_Shop_Type1` FOREIGN KEY (`Shop_Type_ID`) REFERENCES `Shop_Type` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `User_Preferences`
--
ALTER TABLE `User_Preferences`
ADD CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `User` (`id`),
ADD CONSTRAINT `user_preferences_ibfk_2` FOREIGN KEY (`Preferences_ID`) REFERENCES `Preferences` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
